import PDFDocument from 'pdfkit';
import dbConnect from '../../../lib/dbConnect';
import User from '../../../lib/models/User';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method not allowed' });
  }

  await dbConnect();
  
  const { userId, quizId, score } = req.body;

  try {
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Create a new PDF document
    const doc = new PDFDocument({ size: 'A4', layout: 'landscape' });

    // Set response headers to trigger a file download
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', attachment; filename=${user.name}_${quizId}_certificate.pdf);

    // Pipe the PDF content to the response
    doc.pipe(res);

    // --- Add content to the PDF ---
    doc.fontSize(40).font('Helvetica-Bold').text('Certificate of Achievement', { align: 'center' });
    doc.moveDown(2);
    doc.fontSize(22).font('Helvetica').text('This is to certify that', { align: 'center' });
    doc.moveDown(1.5);
    doc.fontSize(36).font('Helvetica-Bold').text(user.name, { align: 'center' });
    doc.moveDown(1.5);
    doc.fontSize(22).font('Helvetica').text(has successfully completed the quiz: "${quizId}", { align: 'center' });
    doc.moveDown(1);
    doc.fontSize(28).font('Helvetica-Bold').text(With a score of ${score.toFixed(2)}%, { align: 'center' });
    doc.moveDown(3);
    doc.fontSize(16).font('Helvetica').text(Date Issued: ${new Date().toLocaleDateString()}, { align: 'center' });

    // Finalize the PDF and end the stream
    doc.end();

  } catch (error) {
    console.error("Error generating certificate:", error);
    res.status(500).json({ message: 'Error generating certificate.' });
  }
}