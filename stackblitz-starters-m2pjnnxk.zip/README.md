LMS Quiz & Certificate Portal
A simple Next.js app to take quizzes and get a PDF certificate.
✨ Features
● 📝 Take quizzes fetched from a database.
● 💯 Get instant results and a pass/fail status.
● 📜 Download a custom PDF certificate if you pass.
💻 Tech Stack
Next.js, MongoDB, Mongoose, and pdfkit.
🚀 How to Run
1. Clone & Install
In your terminal, run these commands:
Bash
# Clone the project
git clone <your-repository-url>
# Go into the project folder
cd lms-certification-portal
# Install all needed packages
npm install
2. Add Database Connection
Create a new file in the main folder called .env.local and add your MongoDB connection string.
Plaintext
# .env.local
MONGO_URI=your_mongodb_connection_string_here
3. Add Sample Data
In your MongoDB database, create a users collection and a questions collection.
● Add one user to the users collection and copy their _id.
● Add a few questions with the same quizId (e.g., "JS101") to the questions collection.
4. Update User ID
Open pages/index.js and paste the user _id you copied.
JavaScript
// pages/index.js
const MOCK_USER_ID = "paste_your_user_id_here";
5. Start the App
Run this command in your terminal:
Bash
npm run dev
Now, open http://localhost:3000 in your browser to use the app!