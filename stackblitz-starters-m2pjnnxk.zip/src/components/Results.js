import React from 'react';
import axios from 'axios';

const Result = ({ result, quizId, userId }) => {
  const passStatus = result.score >= 50 ? 'Passed ✅' : 'Failed ❌';

  const handleDownloadCertificate = () => {
    axios({
      url: '/api/certificate/generate', // API endpoint
      method: 'POST',
      responseType: 'blob', // This is crucial for handling file downloads
      data: {
        userId,
        quizId,
        score: result.score,
      },
    })
    .then((response) => {
      // Create a URL for the PDF blob
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      // Set the filename for the download
      link.setAttribute('download', Certificate-${quizId}.pdf);
      document.body.appendChild(link);
      link.click();
      
      // Clean up by revoking the object URL and removing the link
      link.parentNode.removeChild(link);
      window.URL.revokeObjectURL(url);
    })
    .catch(err => console.error("Error downloading certificate:", err));
  };

  return (
    <div className="result-container">
      <h2>Quiz Result</h2>
      <p>Your Score: <strong>{result.score.toFixed(2)}%</strong></p>
      <p>Status: <strong>{passStatus}</strong></p>
      {result.score >= 50 && (
         <button onClick={handleDownloadCertificate}>
           Download Certificate 📜
         </button>
      )}
    </div>
  );
};

export default Result;