import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Quiz = ({ quizId, userId, showResults }) => {
  const [questions, setQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // API URL is a relative path in Next.js
    axios.get(/api/quiz/${quizId})
      .then(res => {
        setQuestions(res.data);
        setLoading(false);
      })
      .catch(err => {
        console.error("Error fetching quiz questions:", err);
        setLoading(false);
      });
  }, [quizId]);

  const handleOptionSelect = (questionId, selectedOption) => {
    setAnswers({ ...answers, [questionId]: selectedOption });
  };

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const handleSubmit = () => {
    // Submit answers to the backend API route
    axios.post('/api/quiz/submit', { quizId, userId, answers })
      .then(res => {
        showResults(res.data); // Callback to show the result component
      })
      .catch(err => console.error("Error submitting quiz:", err));
  };

  if (loading) {
    return <div>Loading quiz... ⏳</div>;
  }

  if (questions.length === 0) {
    return <div>No questions found for this quiz. Please check the quiz ID.</div>;
  }

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <div className="quiz-container">
      <h3>{currentQuestion.questionText}</h3>
      <div className="options">
        {currentQuestion.options.map((option, index) => (
          <div key={index} className="option">
            <input
              type="radio"
              id={${currentQuestion._id}-${index}}
              name={currentQuestion._id}
              value={option}
              onChange={() => handleOptionSelect(currentQuestion._id, option)}
              checked={answers[currentQuestion._id] === option}
            />
            <label htmlFor={${currentQuestion._id}-${index}}>{option}</label>
          </div>
        ))}
      </div>
      <div className="navigation-buttons">
        {currentQuestionIndex < questions.length - 1 ? (
          <button onClick={handleNext} disabled={!answers[currentQuestion._id]}>
            Next
          </button>
        ) : (
          <button onClick={handleSubmit} disabled={!answers[currentQuestion._id]}>
            Submit
          </button>
        )}
      </div>
    </div>
  );
};

export default Quiz;